const express = require('express');
const router = express.Router();
const { getAllStudents, getStudentById, getStudentsByYear } = require('../services/studentService');


router.get('/', async (req, res) => {
    try {
        const students = await getAllStudents();
        res.status(200).json(students);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get student by ID
router.get('/:id', async (req, res) => {
    try {
        const student = await getStudentById(req.params.id);
        res.status(200).json(student);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

//Q3
router.get('/year/:year', async (req, res) => {
    try {
        const students = await getStudentsByYear(req.params.year);
        res.status(200).json(students);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
