const express = require('express');
const router = express.Router();
const { getAllBooks, getBookById, getBooksByGenre } = require('../services/bookService');
const { filterByField } = require('../services/commonService');
const Book = require('../models/Book');
const Student = require('../models/Student');

router.get('/', async (req, res) => {
    try {
        const books = await getAllBooks();
        res.status(200).json(books);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

//Q2
router.get('/genre/:genre', async (req, res) => {
    try {
        const books = await getBooksByGenre(req.params.genre);
        res.status(200).json(books);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


//Q4 -common
router.get('/genre/:genre', async (req, res) => {
    try {
        const books = await filterByField(Book, 'genre', req.params.genre);
        if (books.length === 0) {
            return res.status(404).json({ message: "No books found for this genre" });
        }
        res.status(200).json(books);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});
router.get('/year/:year', async (req, res) => {
    try {
        const students = await filterByField(Student, 'year', req.params.year);
        if (students.length === 0) {
            return res.status(404).json({ message: "No students found for this year" });
        }
        res.status(200).json(students);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


// Get book by ID
router.get('/:id', async (req, res) => {
    try {
        const book = await getBookById(req.params.id);
        res.status(200).json(book);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


module.exports = router;
