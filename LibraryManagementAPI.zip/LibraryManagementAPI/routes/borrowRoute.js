const express = require('express');
const router = express.Router();
const Student = require('../models/Student');
const Borrow = require('../models/Borrow');

router.get('/', async (req, res) => {
    try{
        const results = await Book.find();
        res.status(200).json(results);
    } catch(error){
        res.status(500).send("Server Error!");
    }
});

router.get('/:id', async (req, res) => {
    try{
        const results = await Book.findById(req.params.id);
        res.status(200).json(results || "cannot Borrow!");
    } catch (error){
        res.status(500).send("Server Error!");
    }
});

router.post('/borrow', async (req, res) => {
    try {
        const { studentId, bookId } = req.body;

        // Ensure both student and book IDs exist
        const student = await Student.findById(studentId);
        const book = await Book.findById(bookId);

        if (!student || !book) {
            return res.status(404).json({ message: "Student or Book not found!" });
        }

        // Check if the student has more than 2 unreturned books
        const unreturnedBooks = await Borrow.find({
            student: studentId,
            returned: false
        });

        if (unreturnedBooks.length >= 2) {
            return res.status(400).json({ message: "Student has more than 2 unreturned books!" });
        }

        // Check if there are available copies of the book
        if (book.copiesAvailable <= 0) {
            return res.status(400).json({ message: "No available copies for borrowing!" });
        }

        // Decrease available copies by 1
        book.copiesAvailable -= 1;
        await book.save();

        // Add the borrow record
        const borrowRecord = new Borrow({
            student: studentId,
            book: bookId,
            borrowDate: Date.now(),
            returned: false
        });

        await borrowRecord.save();

        res.status(200).json({ message: "Book borrowed successfully!" });

    } catch (error) {
        res.status(500).send("Server Error!");
    }
});

const { borrowBook } = require('../services/borrowService');

router.post('/borrow', async (req, res) => {
    try {
        const { studentId, bookId } = req.body;
        const result = await borrowBook(studentId, bookId);
        res.status(200).json({ message: result });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


//Q5
router.post('/', async (req, res) => {
    try {
        const { studentId, bookId } = req.body;
        const message = await borrowBook(studentId, bookId);
        res.status(200).json({ message });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});


router.post('/return', async (req, res) => {
    try {
        const { borrowId } = req.body;
        const message = await returnBook(borrowId);
        res.status(200).json({ message });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});


module.exports = router;